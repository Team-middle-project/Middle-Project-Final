package dev.midproject.auction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionApplicationTests {

	@Test
	void contextLoads() {
	}

}
