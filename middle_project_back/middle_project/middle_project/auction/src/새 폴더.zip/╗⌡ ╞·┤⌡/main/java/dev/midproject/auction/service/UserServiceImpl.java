package dev.midproject.auction.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dev.midproject.auction.model.dto.UserDTO;
import dev.midproject.auction.model.entity.UserDB;
import dev.midproject.auction.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepository userRepository;

    @Override
    public List<UserDTO> findAllUsers() {
        // bookRepository.findAll();
        List<UserDB> list = userRepository.findAll();
        // bookRepository.
        List<UserDTO> result = list.stream().map(r -> new UserDTO(r)).collect(Collectors.toList());
        System.out.println(list);
        System.out.println(result);
        return result;
    }

}
