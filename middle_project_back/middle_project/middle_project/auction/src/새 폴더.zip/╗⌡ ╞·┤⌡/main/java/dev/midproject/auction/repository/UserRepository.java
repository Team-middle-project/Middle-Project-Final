package dev.midproject.auction.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import dev.midproject.auction.model.entity.UserDB;

public interface UserRepository extends JpaRepository<UserDB, Long>{
    UserDB findByName(String name);
}
