package dev.midproject.auction.model.dto;

import dev.midproject.auction.model.entity.UserDB;

public class UserDTO {
    private Long id;
    private String userID;
    private String pw;
    private String name;
    private int age;
    private String address;
    // private ProductDTO produckDTO;


    
    public UserDTO(UserDB user) {
        this.id = user.getId();
        this.userID = user.getUserId();
        this.pw = user.getUserPw();
        this.name = user.getUserName();
        this.age = user.getUserAge();
        this.address = user.getUserAddress();
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getPw() {
        return pw;
    }
    public void setPw(String pw) {
        this.pw = pw;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    
    
    
}
